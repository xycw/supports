{:R('Common/Html/html_start')} 
<header id="header">{:R('Common/Layout/menu')}</header>
<div class="container">
{__CONTENT__}
</div>
<footer id="footer">{:R('Common/Layout/footer')}</footer>
{:R('Common/Html/html_end')} 
