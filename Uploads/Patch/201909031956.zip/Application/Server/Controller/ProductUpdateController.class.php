<?php
namespace Server\Controller;
use Think\Controller;

class ProductUpdateController extends Controller {
    public function index(){
        $upload = new \Think\Upload();
        $upload->maxSize = 10485760; //  设置附件上传大小
        $upload->hash = false;
        $upload->replace = true;
        $upload->rootPath = ROOT_PATH;
        $upload->subName = 'patch'; //附件路径
        $upload->exts = array('update_product','txt'); //  设置附件上传类型
        $upload_info = $upload->upload();
        $response = array();
        if ($upload_info) {//上传错误提示错误信息
            $file_content = file_get_contents(ROOT_PATH . $upload_info['file']['savepath']  . $upload_info['file']['savename']);
            $data = uncompress_decode($file_content);
            $result = array();
            foreach($data as $entry_update){
                $check_language = D('languages')->where(array('code'=>$entry_update['language_code']))->field('languages_id')->find();
                //语言检测
                if(!$check_language){
                    $result[] = array('product_id'=>$entry_update['product_id'], 'language_code'=>$entry_update['language_code'], 'error'=>'更新失败!请先在网站上安装对应语言包!');
                    continue;
                }                    
                //分类查询
                $category = I('category');
                if(preg_match('~^\d+$~', $category)){
                    $master_categories_id = (int)$category;
                    $categories = array($master_categories_id);
                }else{
                    if(empty($category)){
                        $category = $entry_update['featured_category'];
                    }
                    $part_category = explode('|||', $category);//分类1===分类2===分类3|||分类A===分类B
                    $master_categories_id = 0;
                    $categories = array();
                    foreach ($part_category as $category){
                        $multi_category = explode('===', $category);
                        $parent_categories_id = 0;
                        foreach($multi_category as $entry_catetory){
                            if(empty($entry_catetory)) continue;
                            $check_categories = D('categories')->alias('c')->join('__CATEGORIES_DESCRIPTION__ cd ON cd.categories_id=c.categories_id')
                                    ->where(array('cd.categories_name'=>$entry_catetory, 'language_id'=>$check_language['languages_id'], 'c.parent_id'=>$parent_categories_id))
                                    ->field('c.categories_id')->find();
                            if($check_categories){
                                $parent_categories_id = $check_categories['categories_id'];
                            }else{
                                D('categories')->add(array('parent_id'=>$parent_categories_id, 'date_added'=>date('Y-m-d H:i:s'), 'categories_status'=>1));
                                $parent_categories_id = D('categories')->getLastInsID();
                                D('categories_description')->add(array(
                                    'categories_id'=>$parent_categories_id,
                                    'language_id'=>$check_language['languages_id'],
                                    'categories_name'=>$entry_catetory,
                                ), array(), true);
                            }
                        }
                        $categories[] = $parent_categories_id;
                    }
                    $master_categories_id = $categories[0];
                }

                //品牌
                $manufacturers_id = 0;
                $check_manufacturers = D('manufacturers')->alias('m')->join('__MANUFACTURERS_INFO__ mi ON mi.manufacturers_id=m.manufacturers_id')
                                    ->where(array('m.manufacturers_name'=>$entry_update['product_brand']))->field('m.manufacturers_id')->find();
                if($check_manufacturers){
                    $manufacturers_id = $check_manufacturers['manufacturers_id'];
                }else{
                    D('manufacturers')->add(array(
                        'manufacturers_name'=>$entry_update['product_brand'],
                        'date_added'=>date('Y-m-d H:i:s')
                    ));
                    $manufacturers_id = D('manufacturers')->getLastInsID();
                    D('manufacturers_info')->add(array(
                        'manufacturers_id'  =>$manufacturers_id,
                        'languages_id'      =>$check_language['languages_id']
                    ));
                }
                
                //产品查询                
                $check_product = D('products')->where(array('products_model'=>$entry_update['product_model']))->field('products_id')->find();                
                $data_products = array(
                        'products_quantity'=>999,
                        'products_model'=>$entry_update['product_model'],
                        'products_image'=>$entry_update['product_images'],
                        'products_price'=>$entry_update['product_price'],
                        'master_categories_id'=>$master_categories_id,
                        'manufacturers_id'=>$manufacturers_id,
                        'products_status'=>I('status'),
                        'products_date_added'=>('0000-00-00'==$entry_update['date_added']?date('Y-m-d'):$entry_update['date_added']),
                );
                if($check_product){
                    D('products')->where(array('products_id'=>$check_product['products_id']))->save($data_products);
                    $products_id = $check_product['products_id'];
                }else{
                    D('products')->add($data_products);
                    $products_id = D('products')->getLastInsID();
                }
                
                D('products_description')->add(array(
                    'products_id'=>$products_id,
                    'products_model'=>$check_language['languages_id'],
                    'products_name'=>$entry_update['product_name'],
                    'products_description'=>$entry_update['product_description'],
                ), array(), true);
                D('products_to_categories')->where(array('products_id'=>$products_id))->delete();
                foreach($categories as $categories_id){
                    D('products_to_categories')->add(array('products_id'=>$products_id,'categories_id'=>$categories_id), array(), true);
                }

                //特价
                if($entry_update['speciel_price']>0 && $entry_update['speciel_price']<$entry_update['product_price']){
                    $check_specials = D('specials')->where(array('products_id'=>$products_id))->field('specials_id')->find();
                    if($check_specials===null)
                        D('specials')->add(array('products_id'=>$products_id,'specials_new_products_price'=>$entry_update['speciel_price']));
                    else
                        D('specials')->where(array('specials_id'=>$check_specials['specials_id']))->save(array('products_id'=>$products_id,'specials_new_products_price'=>$entry_update['speciel_price']));
                }else{
                    D('specials')->where(array('products_id'=>$products_id))->delete();
                }
                //属性 格式:属性名1==属性类型:属性值1.1,属性值1.2|||属性名2==属性类型:属性值2.1,属性值2.2
                if(empty($entry_update['product_attribute'])){
                    D('products_attributes')->where(array('products_id'=>$products_id))->delete();
                }else{
                    $attributes = explode('|||', $entry_update['product_attribute']);
                    $data_attributes = array();
                    $data_products_attribute = array();
                    $option_name_sort = 0;
                    foreach($attributes as $attribute){
                        $option_name_sort++;
                        list($option_name, $string_option_values) = explode(':', $attribute);
                        list($option_name, $option_type) = explode('==', $option_name);
                        $options_values = explode(',', $string_option_values);
                        //检测属性
                        $check_option_type = D('products_options_types')->where(array('products_options_types_name'=>$option_type))->field('products_options_types_id')->find();
                        if($check_option_type){
                            $check_products_options = D('products_options')->where(array('language_id'=>$check_language['languages_id'], 'products_options_name'=>$option_name))->field('products_options_id')->find();
                            
                            if($check_products_options===null){
                                $max_products_options_id = D('products_options')->field('MAX(products_options_id) as products_options_id')->find();
                                $max_products_options_id = ($max_products_options_id?(1+$max_products_options_id['products_options_id']):1);
                                D('products_options')->add(array('products_options_id'=>$max_products_options_id, 'language_id'=>$check_language['languages_id'], 'products_options_name'=>$option_name, 'products_options_sort_order'=>$option_name_sort,'products_options_type'=>$check_option_type['products_options_types_id']));
                                $products_options_id = D('products_options')->getLastInsID();
                            } else {
                                D('products_options')->where(array('products_options_id'=>$check_products_options['products_options_id']))->save(array('products_options_sort_order'=>$option_name_sort));
                                $products_options_id = $check_products_options['products_options_id'];
                            }
                            $options_values_name_sort = 1;
                            foreach ($options_values as $options_values_name){
                                $check_products_options_values = D('products_options_values')->where(array('language_id'=>$check_language['languages_id'], 'products_options_values_name'=>$options_values_name))->field('products_options_values_id')->find();
                                if($check_products_options_values===null){
                                    $max_products_options_values_id = D('products_options_values')->field('MAX(products_options_values_id) as products_options_values_id')->find();
                                    $max_products_options_values_id = ($max_products_options_values_id?(1+$max_products_options_values_id['products_options_values_id']):1);
                                    D('products_options_values')->add(array('products_options_values_id'=>$max_products_options_values_id,'language_id'=>$check_language['languages_id'], 'products_options_values_name'=>$options_values_name, 'products_options_values_sort_order'=>$options_values_name_sort));
                                    $products_options_values_id = $max_products_options_values_id['products_options_values_id'];
                                }else{
                                    D('products_options_values')->where(array('products_options_values_id'=>$check_products_options_values['products_options_values_id']))->save(array('products_options_values_sort_order'=>$options_values_name_sort));
                                    $products_options_values_id = $check_products_options_values['products_options_values_id'];
                                }
                                
                                $check_options_to_values = D('products_options_values_to_products_options')->where(array('products_options_id'=>$products_options_id, 'products_options_values_id'=>$products_options_values_id))->find();
                                if($check_options_to_values===null){
                                    D('products_options_values_to_products_options')->add(array('products_options_id'=>$products_options_id, 'products_options_values_id'=>$products_options_values_id));
                                }
                                $check_products_attributes = D('products_attributes')->where(array('products_id'=>$products_id, 'options_id'=>$products_options_id, 'options_values_id'=>$products_options_values_id))->field('products_attributes_id,products_options_sort_order')->find();
                                if($check_products_attributes===null){
                                    D('products_attributes')->add(array('products_id'=>$products_id, 'options_id'=>$products_options_id, 'options_values_id'=>$products_options_values_id, 'products_options_sort_order'=>$options_values_name_sort));
                                }elseif($check_products_attributes['products_options_sort_order']!=$options_values_name_sort){
                                    D('products_attributes')->where(array('products_attributes_id'=>$check_products_attributes['products_attributes_id']))->save(array('products_options_sort_order'=>$options_values_name_sort));
                                }
                                $data_products_attribute[] = $products_id.'-'.$products_options_id.'-'.$products_options_values_id;
                                $options_values_name_sort++;
                            }
                        }                      
                    }
                    $attribute = D('products_attributes')->where(array('products_id'=>$products_id))->field('products_id,options_id,options_values_id')->select();
                    foreach($attribute as $entry){
                        if(!in_array($entry['products_id'].'-'.$entry['options_id'].'-'.$entry['options_values_id'], $data_products_attribute)){
                            D('products_attributes')->where(array('products_id'=>$products_id, 'options_id'=>$entry['options_id'], 'options_values_id'=>$entry['options_values_id']))->delete();
                        }
                    }                    
                }                
                
                if($entry_update['has_products_attr']==1){
                    //属性筛选 格式:属性名1:属性值1.1,属性值1.2|||属性名2:属性值2.1,属性值2.2
                    if(empty($entry_update['products_attr'])){
                        D('products_attr')->where(array('products_id'=>$products_id))->delete();
                    }else{
                        $attributes = explode('|||', $entry_update['products_attr']);
                        $data_attributes = array();
                        $attr = array();
                        foreach($attributes as $attribute){
                            list($option_name, $string_option_values) = explode(':', $attribute);
                            $options_values = explode(',', $string_option_values);
                            foreach($options_values as $options_value){
                                $check_attr_desc = D('attr_description')->where(array('language_id'=>$check_language['languages_id'], 'attr_name'=>$option_name, 'attr_value'=>$options_value))->field('attr_id')->find();
                                if($check_attr_desc==false){
                                    $max_attr_id = D('attr_description')->field('MAX(attr_id) as attr_id')->find();
                                    $max_attr_id = ($max_attr_id?(1+$max_attr_id['attr_id']):1);
                                    D('attr_description')->add(array('attr_id'=>$max_attr_id,'language_id'=>$check_language['languages_id'], 'attr_name'=>$option_name, 'attr_value'=>$options_value));
                                    $attr_id = $max_attr_id;
                                    $attr[] = $check_attr_desc['attr_id'];
                                }else{
                                    $attr_id = $check_attr_desc['attr_id'];
                                    $attr[] = $check_attr_desc['attr_id'];
                                }
                                $check_attr = D('attr')->where(array('attr_id'=>$attr_id))->find();
                                if($check_attr==false)
                                    D('attr')->add(array('attr_id'=>$attr_id,'attr_name'=>$option_name, 'attr_value'=>$options_value));
                            }
                        }
                        D('products_attr')->where(array('products_id'=>$products_id))->delete();
                        $attr_index_data = array();
                        foreach ($attr as $attr_id){
                            D('products_attr')->add(array('products_id'=>$products_id, 'attr_id'=>$attr_id));
                            $table_index = ceil($attr_id/63);
                            $attr_index_table = 'product_attr_index'.$table_index;
                            if(!isset($attr_index_data[$attr_index_table])) $attr_index_data[$attr_index_table] = array();
                            $attr_index_data[$attr_index_table][] = $attr_id;
                        }
                        $model = new \Think\Model();
                        foreach ($attr_index_data as $attr_index_table=>$attr){

                            $attr = array_unique($attr);
                            $check_table = $model->query("select TABLE_NAME from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA='".C('DB_NAME')."' and TABLE_NAME='".C('DB_PREFIX').$attr_index_table."'", false);
                            if(empty($check_table)){
                                $create_sql = 'CREATE TABLE IF NOT EXISTS `'.C('DB_PREFIX').$attr_index_table.'` (`products_id` int(11) NOT NULL';
                                foreach ($attr as $attr_id)
                                    $create_sql .= ',`'.$attr_id.'` int(11) NOT NULL';
                                $create_sql .= ') ENGINE=MyISAM DEFAULT CHARSET=utf8;';     
                                $model->execute($create_sql);
                                $sql = 'ALTER TABLE `'.C('DB_PREFIX').$attr_index_table.'` ADD PRIMARY KEY (`products_id`)';   
                                foreach ($attr as $attr_id){
                                    $sql .= ', ADD KEY `'.$attr_id.'` (`'.$attr_id.'`)';   
                                } 
                                $model->execute($sql);
                            }else{
                                D($attr_index_table)->where(array('products_id'=>$products_id))->delete();
                                $fileds = D($attr_index_table)->getDbFields(array('table'=>$attr_index_table));
                                foreach ($attr as $attr_id){
                                    if(!in_array($attr_id, $fileds)){
                                        $sql = 'ALTER TABLE `'.C('DB_PREFIX').$attr_index_table.'` ADD `'.$attr_id.'` INT NOT NULL , ADD INDEX (`'.$attr_id.'`)';   
                                        $model->execute($sql);
                                    }
                                } 
                            }   
                            $sql = 'INSERT INTO `'.C('DB_PREFIX').$attr_index_table.'`(`products_id`,`'.implode('`,`', $attr).'`) VALUES ( '.$products_id;
                            foreach ($attr as $attr_id){
                                $sql .= ',1';
                            }
                            $sql .= ')';
                            $model->execute($sql);
                        }
                    }
                }
                $result[] = array('product_id'=>$entry_update['product_id'], 'language_code'=>$entry_update['language_code']);
            }
            $response = array('status'=>1, 'result'=>$result);
        }else
            $response = array('status'=>0, 'error'=>$upload->getError().var_export($_FILES, true));
        
        echo json_encode($response);
        exit;
    }
}